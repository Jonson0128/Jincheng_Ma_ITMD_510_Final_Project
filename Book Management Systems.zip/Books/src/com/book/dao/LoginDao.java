package com.book.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.book.model.Login;
import com.book.model.User;
import com.book.utlities.ConnectionFactory;

public class LoginDao {
	private static ConnectionFactory connFactory = ConnectionFactory.getConnectionFactory();
	
	public int checkCredential(Login login)
	{
		int resultCount=0;
		try {
			Connection conn = connFactory.getConnection();
			String sql ="SELECT * FROM users WHERE userName=? AND password=?";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			
			pStmt.setNString(1,login.getUserName());
			pStmt.setNString(2,login.getPassword());
			
			try {
				conn.setAutoCommit(false);
				ResultSet resultSet = pStmt.executeQuery();
				if (resultSet.next()) {
					resultCount++;
				}
				System.out.println("User Found");
				return resultCount;
			}catch (Exception e) {
				e.printStackTrace();
				return 0;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
}
