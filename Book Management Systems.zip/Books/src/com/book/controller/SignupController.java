package com.book.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import com.book.dao.UserDao;
import com.book.model.User;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class SignupController   implements Initializable {

	@FXML
	private Label info;
	@FXML
	private Label update;
	@FXML
	private TextField firstName;
	@FXML
	private TextField lastName;
	@FXML
	private TextField userName;
	@FXML
	private TextField password;
	@FXML
	private TextField email;
	@FXML
	private TextField mobile;
	@FXML
	private TextArea address;
	@FXML
	public Button signUp;
	@FXML
	public Button backButton;
	
	private UserDao userdao;
	public void addNewUser(ActionEvent event)
	{
		User user=new User(firstName.getText(), lastName.getText(), userName.getText(), password.getText(), email.getText(), mobile.getText(), address.getText());
		int result=userdao.save(user);
		System.out.println("result : "+result);
		info.setText("");
		if(result==0)
		{
			update.setText("System Error");
		}else
		{
			update.setText("New Record Inserted");
			firstName.setText("");
		}
	}
	
	public void backToLogin(ActionEvent event) throws IOException
	{
		System.out.println("back");
		 System.out.println("signup");
		 Stage stage;
		 Scene scene;
		 Parent root;
		 //root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
		 root =(AnchorPane)FXMLLoader.load(getClass().getClassLoader().getResource("com/book/view/login.fxml"));
		 stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		 scene = new Scene(root);
		 stage.setScene(scene);
		 stage.show();
	}
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		userdao=new UserDao();
	}
	
}
