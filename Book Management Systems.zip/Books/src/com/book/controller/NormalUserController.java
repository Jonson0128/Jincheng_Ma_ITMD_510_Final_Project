package com.book.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import com.book.dao.BookDao;
import com.book.model.Book;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class NormalUserController implements Initializable{

	
	@FXML
	public Button backButton;
	@FXML
	private TableColumn<Book, Integer> column1;
	@FXML
	private TableColumn<Book, String> column2;
	@FXML
	private TableColumn<Book, String> column3;
	@FXML
	private TableColumn<Book, String> column4;
	@FXML
	private TableColumn<Book, String> column5;
	@FXML
	private TableColumn<Book, Float> column6;
	@FXML
	private TableColumn<Book, String> column7;
	@FXML
	private TableView<Book> table;
	private BookDao bookdao;
	private  Book currentSelectedBook;
	
	public void backToLogin(ActionEvent event) throws IOException {
		System.out.println("back");
		System.out.println("signup");
		Stage stage;
		Scene scene;
		Parent root;
		// root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
		root = (AnchorPane) FXMLLoader.load(getClass().getClassLoader().getResource("com/book/view/login.fxml"));
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		bookdao=new BookDao();
		getAll();
	}
	
	public  void getAll()
	{
		ObservableList<Book> allBook=bookdao.getAll();
		System.out.println(allBook);
		table.setItems(allBook);
		column1.setCellValueFactory(new PropertyValueFactory<Book, Integer>("bookId"));
		column2.setCellValueFactory(new PropertyValueFactory<Book, String>("bookName"));
		column3.setCellValueFactory(new PropertyValueFactory<Book, String>("author"));
		column4.setCellValueFactory(new PropertyValueFactory<Book, String>("publisher"));
		column5.setCellValueFactory(new PropertyValueFactory<Book, String>("catogory"));
		column6.setCellValueFactory(new PropertyValueFactory<Book, Float>("price"));
		column7.setCellValueFactory(new PropertyValueFactory<Book, String>("isbn"));
		
	}
}
