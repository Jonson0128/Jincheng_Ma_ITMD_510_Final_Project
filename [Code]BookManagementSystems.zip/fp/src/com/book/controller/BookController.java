package com.book.controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import com.book.dao.BookDao;
import com.book.model.Book;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class BookController implements Initializable {

	@FXML
	private Label update;
	@FXML
	private TextField bookName;
	@FXML
	private TextField author;
	@FXML
	private TextField publisher;
	@FXML
	private TextField catogory;
	@FXML
	private TextField price;
	@FXML
	private TextField isbn;
	@FXML
	private TextArea description;
	@FXML
	public Button add_btn;
	@FXML
	public Button update_btn;
	@FXML
	public Button delete_btn;
	@FXML
	public Button backButton;
	@FXML
	private TableColumn<Book, Integer> column1;
	@FXML
	private TableColumn<Book, String> column2;
	@FXML
	private TableColumn<Book, String> column3;
	@FXML
	private TableColumn<Book, String> column4;
	@FXML
	private TableColumn<Book, String> column5;
	@FXML
	private TableColumn<Book, Float> column6;
	@FXML
	private TableColumn<Book, String> column7;
	@FXML
	private TableView<Book> table;
	private BookDao bookdao;
	private  Book currentSelectedBook;
	
	public void save(ActionEvent event) {
		System.out.println("save");
		Book book = null;
		try {
		book=new Book(0,bookName.getText(), description.getText(), author.getText(), publisher.getText(), catogory.getText(), Float.parseFloat(price.getText()), isbn.getText());
		System.out.println(book);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		int result=bookdao.save(book);
		if(result==0)
		{
			update.setText("System Error");
		}else
		{
			update.setText("New Record Inserted");
			
		}
		getAll();
		clearFields();
	}

	public void update(ActionEvent event) {
		System.out.println("update");
		Book book = null;
		try {
		book=new Book(currentSelectedBook.getBookId(),bookName.getText(), description.getText(), author.getText(), publisher.getText(), catogory.getText(), Float.parseFloat(price.getText()), isbn.getText());
		System.out.println(book);
		int result=bookdao.update(book);
		if(result==0)
		{
			update.setText("Error In Upadation");
		}
		else
		{
			update.setText("The Record Is Updated");
		}
		}catch (Exception e) {
			e.printStackTrace();
		}
		getAll();
		clearFields();
	}

	public void delete(ActionEvent event) {
		System.out.println("delete");
		Book book = null;
		try {
		book=new Book(currentSelectedBook.getBookId(),bookName.getText(), description.getText(), author.getText(), publisher.getText(), catogory.getText(), Float.parseFloat(price.getText()), isbn.getText());
		System.out.println(book);
		int result=bookdao.delete(currentSelectedBook.getBookId());
		if(result==0)
		{
			update.setText("Error In Deletion");
		}
		else
		{
			update.setText("The Record Is Deleted");
		}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		getAll();
		clearFields();
	}

	public void backToLogin(ActionEvent event) throws IOException {
		System.out.println("back");
		System.out.println("signup");
		Stage stage;
		Scene scene;
		Parent root;
		// root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
		root = (AnchorPane) FXMLLoader.load(getClass().getClassLoader().getResource("com/book/view/login.fxml"));
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		bookdao=new BookDao();
		getAll();
	}
	
	public  void getAll()
	{
		ObservableList<Book> allBook=bookdao.getAll();
		System.out.println(allBook);
		table.setItems(allBook);
		column1.setCellValueFactory(new PropertyValueFactory<Book, Integer>("bookId"));
		column2.setCellValueFactory(new PropertyValueFactory<Book, String>("bookName"));
		column3.setCellValueFactory(new PropertyValueFactory<Book, String>("author"));
		column4.setCellValueFactory(new PropertyValueFactory<Book, String>("publisher"));
		column5.setCellValueFactory(new PropertyValueFactory<Book, String>("catogory"));
		column6.setCellValueFactory(new PropertyValueFactory<Book, Float>("price"));
		column7.setCellValueFactory(new PropertyValueFactory<Book, String>("isbn"));
		
	}
	
	   	@FXML
	    void mouseClicked(MouseEvent event) {
		   System.out.println("mouse clicked");
		   currentSelectedBook=table.getSelectionModel().getSelectedItem();
		   System.out.println(currentSelectedBook);
		   bookName.setText(currentSelectedBook.getBookName());
		   author.setText(currentSelectedBook.getAuthor());
		   
		   publisher.setText(currentSelectedBook.getPublisher());
		   catogory.setText(currentSelectedBook.getCatogory());
		   price.setText(""+currentSelectedBook.getPrice());
		   isbn.setText(currentSelectedBook.getIsbn());
		   description.setText(currentSelectedBook.getDescription());
		   
	    }
	   	
	   	public void clearFields()
	   	{
	   	 bookName.setText("");
		 author.setText("");
		 publisher.setText("");
		 catogory.setText("");
		 price.setText("");
		 isbn.setText("");
		 description.setText("");
	   	}

}
