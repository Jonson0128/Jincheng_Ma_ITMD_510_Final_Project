package com.book.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import com.book.dao.LoginDao;
import com.book.model.Login;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class LoginController implements Initializable{
	
	@FXML
	private Label update;
	@FXML
	private TextField userName;
	@FXML
	private TextField password;
	@FXML
	public Button login;
	@FXML
	public Button signup;
	private LoginDao logindao;
	
	public void checkCredential(ActionEvent event) throws IOException
	{
		System.out.println("checkCredential");
		Login login=new Login(userName.getText(), password.getText());
		System.out.println(login);
		int result=logindao.checkCredential(login);
		if(result==0)
		{
			update.setText("Invalid User Credential");
		}
		else
		{
			if(userName.getText().contentEquals("admin")&&password.getText().equals("admin"))
				{
				System.out.println("Admin Logged In");
				 Stage stage;
				 Scene scene;
				 Parent root;
				 root =(AnchorPane)FXMLLoader.load(getClass().getClassLoader().getResource("com/book/view/book.fxml"));
				 stage = (Stage)((Node)event.getSource()).getScene().getWindow();
				 scene = new Scene(root);
				 stage.setScene(scene);
				 stage.show();
				}
				else
				{
					System.out.println("Normal User Logged In");
					 Stage stage;
					 Scene scene;
					 Parent root;
					 root =(AnchorPane)FXMLLoader.load(getClass().getClassLoader().getResource("com/book/view/booViewForNormalUser.fxml"));
					 stage = (Stage)((Node)event.getSource()).getScene().getWindow();
					 scene = new Scene(root);
					 stage.setScene(scene);
					 stage.show();
				}
		}
	}
	public void signup(ActionEvent event) throws IOException
	{
		 System.out.println("signup");
		 Stage stage;
		 Scene scene;
		 Parent root;
		 root =(AnchorPane)FXMLLoader.load(getClass().getClassLoader().getResource("com/book/view/Signup.fxml"));
		 stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		 scene = new Scene(root);
		 stage.setScene(scene);
		 stage.show();
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		logindao=new LoginDao();
	}
	
}
