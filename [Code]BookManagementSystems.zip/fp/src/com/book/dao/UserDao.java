package com.book.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.book.model.User;
import com.book.utlities.ConnectionFactory;

public class UserDao {

	private static ConnectionFactory connFactory = ConnectionFactory.getConnectionFactory();
	public int save(User user)
	{
		try {
			Connection conn = connFactory.getConnection();
				String sql ="INSERT INTO users (firstName, lastName, userName,password,email,mobile,address)VALUES (?,?,?,?,?,?,?)";
				PreparedStatement pStmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
				pStmt.setString(1, user.getFirstName());
				pStmt.setString(2, user.getLastName());
				pStmt.setString(3, user.getUserName());
				pStmt.setString(4, user.getPassword());
				pStmt.setString(5, user.getEmail());
				pStmt.setString(6, user.getMobile());
				pStmt.setString(7, user.getAddress());
			
				int generatedId = 0;
				try {
					conn.setAutoCommit(false);
					pStmt.executeUpdate();
					ResultSet resultSet = pStmt.getGeneratedKeys();

					if (resultSet.next()) {
						generatedId = resultSet.getInt(1);
						System.out.println("generatedId : " + generatedId);
						conn.commit();
					} else {
						conn.rollback();
					}
				} catch (SQLException e) {
					e.printStackTrace();
					try {
						conn.rollback();
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				} finally {
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				System.out.println("New User Saved : " + generatedId);
				return generatedId;
		
	}catch (Exception e) {
		e.printStackTrace();
		return 0;
	}
}
}
